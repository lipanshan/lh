<template>
  <div class="company-info">公司资料</div>
</template>

<script>
export default {
  name: 'CompanyInfo'
}
</script>

<style lang="scss">
</style>