<template>
  <div class="main">
    <div class="main-box">
      <div>
        <img src="../assets/img/ios.png" alt />
        <p>IOS</p>
        <p>升级中...</p>
      </div>
      <div>
        <img src="../assets/img/xcx.png" alt />
        <p>扫描关注小程序</p>
      </div>
      <div>
        <img src="../assets/img/android.png" alt />
        <p>Android</p>
        <p>升级中...</p>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'AppPage'
}
</script>
<style lang="scss" scoped>
@import '../assets/css/download.css'
</style>