<template>
  <div>
    <div class="banner">
      <img src="../assets/img/banner-headhunting.png" alt />
      <p>值得信赖的职业发展伙伴</p>
    </div>
    <div class="content">
      <div class="left-c">
        <img src="../assets/img/headhunting-el.png" alt />
        <div>
          <div>
            <p>top职位</p>
            <p>城市HRVP 地产10强 500万年薪</p>
            <p>城市HRVP 地产10强 500万年薪</p>
            <p>城市HRVP 地产10强 500万年薪</p>
            <p>城市HRVP 地产10强 500万年薪</p>
            <p>城市HRVP 地产10强 500万年薪</p>
            <div class="name">姓名</div>
          </div>
          <div>
            <p>猎中职位</p>
            <p>
              城市HRVP 地产10强 500万年薪
              <span>砸简历</span>
            </p>
            <p>
              城市HRVP 地产10强 500万年薪
              <span>砸简历</span>
            </p>
            <p>
              城市HRVP 地产10强 500万年薪
              <span>砸简历</span>
            </p>
            <p>
              城市HRVP 地产10强 500万年薪
              <span>砸简历</span>
            </p>
            <p>
              城市HRVP 地产10强 500万年薪
              <span>砸简历</span>
            </p>
          </div>
        </div>
      </div>
      <div class="right-c">
        <img src="../assets/img/headhunting-el.png" alt />
        <div>
          <div>
            <p>top职位</p>
            <p>城市HRVP 地产10强 500万年薪</p>
            <p>城市HRVP 地产10强 500万年薪</p>
            <p>城市HRVP 地产10强 500万年薪</p>
            <p>城市HRVP 地产10强 500万年薪</p>
            <p>城市HRVP 地产10强 500万年薪</p>
          </div>
          <div>
            <p>猎中职位</p>
            <p>
              城市HRVP 地产10强 500万年薪
              <span>砸简历</span>
            </p>
            <p>
              城市HRVP 地产10强 500万年薪
              <span>砸简历</span>
            </p>
            <p>
              城市HRVP 地产10强 500万年薪
              <span>砸简历</span>
            </p>
            <p>
              城市HRVP 地产10强 500万年薪
              <span>砸简历</span>
            </p>
            <p>
              城市HRVP 地产10强 500万年薪
              <span>砸简历</span>
            </p>
            <div class="name">姓名</div>
          </div>
        </div>
      </div>
      <div class="left-c">
        <img src="../assets/img/headhunting-el.png" alt />
        <div>
          <div>
            <p>top职位</p>
            <p>城市HRVP 地产10强 500万年薪</p>
            <p>城市HRVP 地产10强 500万年薪</p>
            <p>城市HRVP 地产10强 500万年薪</p>
            <p>城市HRVP 地产10强 500万年薪</p>
            <p>城市HRVP 地产10强 500万年薪</p>
            <div class="name">姓名</div>
          </div>
          <div>
            <p>猎中职位</p>
            <p>
              城市HRVP 地产10强 500万年薪
              <span>砸简历</span>
            </p>
            <p>
              城市HRVP 地产10强 500万年薪
              <span>砸简历</span>
            </p>
            <p>
              城市HRVP 地产10强 500万年薪
              <span>砸简历</span>
            </p>
            <p>
              城市HRVP 地产10强 500万年薪
              <span>砸简历</span>
            </p>
            <p>
              城市HRVP 地产10强 500万年薪
              <span>砸简历</span>
            </p>
          </div>
        </div>
      </div>
    </div>
    <div class="list-c">
      <div>
        <img src="../assets/img/headhunting-el.png" alt />
        <div>
          <p>姓名</p>
          <p>个人简介</p>
          <p>行业|行业|行业</p>
        </div>
      </div>
      <div>
        <img src="../assets/img/headhunting-el.png" alt />
        <div>
          <p>姓名</p>
          <p>个人简介</p>
          <p>行业|行业|行业</p>
        </div>
      </div>
      <div>
        <img src="../assets/img/headhunting-el.png" alt />
        <div>
          <p>姓名</p>
          <p>个人简介</p>
          <p>行业|行业|行业</p>
        </div>
      </div>
      <div>
        <img src="../assets/img/headhunting-el.png" alt />
        <div>
          <p>姓名</p>
          <p>个人简介</p>
          <p>行业|行业|行业</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HeadHunt'
}
</script>

<style lang="scss" scoped>
@import '../assets/css/headhunting.css';
</style>