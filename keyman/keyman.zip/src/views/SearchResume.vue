<template>
  <div class="search-resume">
    搜简历
  </div>
</template>

<script>
export default {
  name: 'SearchResume'
}
</script>

<style lang="scss">

</style>