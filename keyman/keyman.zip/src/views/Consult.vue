<template>
  <div class="news">
    <div class="type">
      <div>
        <p>
          <span></span>数据报告
          <span>more>></span>
        </p>
        <img src="../assets/img/news.png" alt />
        <p>
          数据报告数据报告数据报告数据
          报告报告报告报告报告报告
        </p>
        <div>查看详情</div>
      </div>
      <span></span>
      <div>
        <p>
          <span></span>数据报告
          <span>more>></span>
        </p>
        <img src="../assets/img/news.png" alt />
        <p>
          数据报告数据报告数据报告数据
          报告报告报告报告报告报告
        </p>
        <div>查看详情</div>
      </div>
      <span></span>
      <div>
        <p>
          <span></span>数据报告
          <span>more>></span>
        </p>
        <img src="../assets/img/news.png" alt />
        <p>
          数据报告数据报告数据报告数据
          报告报告报告报告报告报告
        </p>
        <div>查看详情</div>
      </div>
    </div>
    <ul>
      <li>
        <img src="../assets/img/news.png" alt />
        <div>
          <p>标题</p>
          <p>文章内容文章内容文章内容文章内容文章内容文章内容文章章内容文章内容文章内容文章 文章内文章内容文章内容文章内容文章内容文章内容文章内容文章内容文章内容文章内容 文章内容</p>
          <p>职人生活摄影大赛·2019-10-25</p>
        </div>
      </li>
      <li>
        <img src="../assets/img/news.png" alt />
        <div>
          <p>标题</p>
          <p>文章内容文章内容文章内容文章内容文章内容文章内容文章章内容文章内容文章内容文章 文章内文章内容文章内容文章内容文章内容文章内容文章内容文章内容文章内容文章内容 文章内容</p>
          <p>职人生活摄影大赛·2019-10-25</p>
        </div>
      </li>
      <li>
        <img src="../assets/img/news.png" alt />
        <div>
          <p>标题</p>
          <p>文章内容文章内容文章内容文章内容文章内容文章内容文章章内容文章内容文章内容文章 文章内文章内容文章内容文章内容文章内容文章内容文章内容文章内容文章内容文章内容 文章内容</p>
          <p>职人生活摄影大赛·2019-10-25</p>
        </div>
      </li>
      <li>
        <img src="../assets/img/news.png" alt />
        <div>
          <p>标题</p>
          <p>文章内容文章内容文章内容文章内容文章内容文章内容文章章内容文章内容文章内容文章 文章内文章内容文章内容文章内容文章内容文章内容文章内容文章内容文章内容文章内容 文章内容</p>
          <p>职人生活摄影大赛·2019-10-25</p>
        </div>
      </li>
      <li>
        <img src="../assets/img/news.png" alt />
        <div>
          <p>标题</p>
          <p>文章内容文章内容文章内容文章内容文章内容文章内容文章章内容文章内容文章内容文章 文章内文章内容文章内容文章内容文章内容文章内容文章内容文章内容文章内容文章内容 文章内容</p>
          <p>职人生活摄影大赛·2019-10-25</p>
        </div>
      </li>
    </ul>
    <div class="news-nav">
      <div>查看更多>></div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Consult'
}
</script>

<style lang="scss" scoped>
@import '../assets/css/news.css';
.news {
  margin: 0 auto;
}
</style>