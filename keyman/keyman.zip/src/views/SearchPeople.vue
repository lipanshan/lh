<template>
  
</template>

<script>
export default {
  name: 'SearchPeople'
}
</script>

<style lang="scss" scoped>

</style>