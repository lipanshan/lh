<template>
  <div class="job-want">求职</div>
</template>

<script>
export default {
  name: 'JobWant'
}
</script>

<style lang="scss">
</style>