<template>
  <div class="my-delivery">我的投递</div>
</template>

<script>
export default {
  name: 'MyDelivery'
}
</script>

<style lang="scss">
</style>