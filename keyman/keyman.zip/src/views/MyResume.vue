<template>
  <div class="my-resume">我的简历</div>
</template>

<script>
export default {
  name: 'MyResume'
}
</script>

<style lang="scss">
</style>