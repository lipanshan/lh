<template>
  <div class="fulltime">
    <div class="seach">
      <div class="seach-box">
        <div>
          <div class="input">
            <input type="text" />
            <div>
              公司行业
              <img src="../assets/img/down.png" alt />
            </div>
            <div>
              职位类型
              <img src="../assets/img/down.png" alt />
            </div>
          </div>
          <div class="confirm">搜索</div>
          <div class="curCity">
            <span>北京</span>
            <img src="../assets/img/down.png" alt />
          </div>
        </div>
        <div class="city">
          <div>北京</div>
          <div>></div>
          <div>不限</div>
          <div>></div>
          <div class="hotCity">
            <div>热门城市:</div>
            <ul>
              <li>全国</li>
              <li>北京</li>
              <li>上海</li>
              <li>全国</li>
              <li>全国</li>
            </ul>
          </div>
          <div class="allCity">全部城市>></div>
        </div>
        <div class="area">
          <div>不限</div>
          <ul>
            <li>朝阳区</li>
            <li>朝阳区</li>
            <li>朝阳区</li>
            <li>朝阳区</li>
            <li>朝阳区</li>
            <li>朝阳区</li>
            <li>朝阳区</li>
            <li>朝阳区</li>
            <li>朝阳区</li>
            <li>朝阳区</li>
            <li>朝阳区</li>
            <li>朝阳区</li>
            <li>朝阳区</li>
            <li>朝阳区</li>
            <li>朝阳区</li>
            <li>朝阳区</li>
            <li>朝阳区</li>
            <li>朝阳区</li>
          </ul>
        </div>
        <div class="option">
          <div>
            <div>工作经验</div>
            <img src="../assets/img/down.png" alt />
          </div>
          <div>
            <div>工作经验</div>
            <img src="../assets/img/down.png" alt />
          </div>
          <div>
            <div>工作经验</div>
            <img src="../assets/img/down.png" alt />
          </div>
          <div>
            <div>工作经验</div>
            <img src="../assets/img/down.png" alt />
          </div>
          <div>
            <div>工作经验</div>
            <img src="../assets/img/down.png" alt />
          </div>
          <div>清空条件选项</div>
        </div>
      </div>
    </div>
    <div class="part-main">
      <div class="content">
        <div class="work-list">
          <ul>
            <li>
              <div>
                <p>
                  <span>数据挖掘</span>
                  <span>20-40k 13薪</span>
                </p>
                <p>
                  <span>北京 海淀区 上地</span>
                  <span>3-5年</span>
                  <span>本科</span>
                </p>
              </div>
              <div>
                <p>醉库</p>
                <p>
                  <span>互联网</span>
                  <span>A轮</span>
                  <span>20-99人</span>
                </p>
              </div>
              <div>
                <p>
                  <img src alt />
                  <span>王先生</span> |
                  <span>研发总监</span>
                </p>
                <p>发于11月4号</p>
              </div>
            </li>
            <li>
              <div>
                <p>
                  <span>数据挖掘</span>
                  <span>20-40k 13薪</span>
                </p>
                <p>
                  <span>北京 海淀区 上地</span>
                  <span>3-5年</span>
                  <span>本科</span>
                </p>
              </div>
              <div>
                <p>醉库</p>
                <p>
                  <span>互联网</span>
                  <span>A轮</span>
                  <span>20-99人</span>
                </p>
              </div>
              <div>
                <p>
                  <img src alt />
                  <span>王先生</span> |
                  <span>研发总监</span>
                </p>
                <p>发于11月4号</p>
              </div>
            </li>
            <li>
              <div>
                <p>
                  <span>数据挖掘</span>
                  <span>20-40k 13薪</span>
                </p>
                <p>
                  <span>北京 海淀区 上地</span>
                  <span>3-5年</span>
                  <span>本科</span>
                </p>
              </div>
              <div>
                <p>醉库</p>
                <p>
                  <span>互联网</span>
                  <span>A轮</span>
                  <span>20-99人</span>
                </p>
              </div>
              <div>
                <p>
                  <img src alt />
                  <span>王先生</span> |
                  <span>研发总监</span>
                </p>
                <p>发于11月4号</p>
              </div>
            </li>
          </ul>
          <div class="list-nav">
            <div class="box">
              <div><</div>
              <div>1</div>
              <div>2</div>
              <div>3</div>
              <div>...</div>
              <div>></div>
            </div>
          </div>
        </div>
        <div class="right-regist">
          <div>
            <p>各大行业职位任你选</p>
            <div>
              <img src="../assets/img/mobile.png" alt />
              <span>+86</span>
              <img src="../assets/img/down2.png" alt />
              <input type="text" placeholder="请输入" />
            </div>
            <div id="box" onselectstart="return false;">
              <div class="bgColor"></div>
              <div class="txt">请按住滑块, 拖动到最右边</div>
              <!--给i标签添加上相应字体图标的类名即可-->
              <div class="slider">
                <img src="../assets/img/next.png" alt />
              </div>
            </div>
            <div>
              <img src="../assets/img/email.png" alt />
              <input type="text" placeholder="请输入" />
              <div>发送验证码</div>
            </div>
            <div>登陆/注册</div>
            <div>
              <input type="checkbox" style="background: #fff;" />
              <span>我已同意用户协议及隐私政策</span>
            </div>
          </div>
          <div class="upload">
            <div>上传简历一键注册</div>
          </div>
          <div class="seen-work">
            <div>看过的职位</div>
            <ul>
              <li>
                <p>
                  <span>移动游戏测试 工程...</span>
                  <span>25-35K</span>
                </p>
                <p>腾讯</p>
              </li>
              <li>
                <p>
                  <span>移动游戏测试 工程...</span>
                  <span>25-35K</span>
                </p>
                <p>腾讯</p>
              </li>
              <li>
                <p>
                  <span>移动游戏测试 工程...</span>
                  <span>25-35K</span>
                </p>
                <p>腾讯</p>
              </li>
            </ul>
          </div>
          <img class="gg" src="../assets/img/5.png" alt />
          <img class="gg" style="margin-bottom: 20px" src="../assets/img/5.png" alt />
        </div>
      </div>
    </div>
    <div class="proposal">
      <div class="proposal-box">
        <div>对搜索结果是否满意</div>
        <div>
          <div>
            <img src="../assets/img/no.png" alt />
            <p>不满意</p>
          </div>
          <div>
            <img src="../assets/img/en.png" alt />
            <p>一般</p>
          </div>
          <div>
            <img src="../assets/img/good.png" alt />
            <p>满意</p>
          </div>
          <div>
            <textarea name id cols="30" rows="10" placeholder="请填写更多反馈建议..."></textarea>
            <div>提交</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'FullTime',
  data () {
    return {
      box: '',
      bgColor: '',
      txt: '',
      slider: '',
      icon: '',
      successMoveDistance: '',
      isSuccess: false,
      downX: 0
    }
  },
  mounted () {
    this.box = this.getEle('#box') //容器
    this.bgColor = this.getEle('.bgColor') //背景色
    this.txt = this.getEle('.txt') //文本
    this.slider = this.getEle('.slider') //滑块
    this.icon = this.getEle('.slider>i')
    this.successMoveDistance = this.box.offsetWidth - this.slider.offsetWidth //解锁需要滑动的距离
    // downX //用于存放鼠标按下时的位置
    // isSuccess = false //是否解锁成功的标志，默认不成功
    this.slider.onmousedown = this.mousedownHandler
  },
  methods: {
    getEle: function(selector) {
      return document.querySelector(selector)
    },
    mousedownHandler: function(e) {
      this.bgColor.style.transition = ''
      this.slider.style.transition = ''
      var e = e || window.event || e.which
      this.downX = e.clientX
      //在鼠标按下时，分别给鼠标添加移动和松开事件
      document.onmousemove = this.mousemoveHandler
      document.onmouseup = this.mouseupHandler
    },
    mousemoveHandler: function(e) {
      var e = e || window.event || e.which
      var moveX = e.clientX
      var offsetX = this.getOffsetX(moveX - this.downX, 0, this.successMoveDistance)
      this.bgColor.style.width = offsetX + 'px'
      this.slider.style.left = offsetX + 'px'

      if (offsetX == this.successMoveDistance) {
        this.success()
      }
      //如果不设置滑块滑动时会出现问题（目前还不知道为什么）
      e.preventDefault()
    },
    mouseupHandler: function(e) {
      if (!this.isSuccess) {
        this.bgColor.style.width = 0 + 'px'
        this.slider.style.left = 0 + 'px'
        this.bgColor.style.transition = 'width 0.8s linear'
        this.slider.style.transition = 'left 0.8s linear'
      }
      document.onmousemove = null
      document.onmouseup = null
    },
    getOffsetX: function(offset, min, max) {
      if (offset < min) {
        offset = min
      } else if (offset > max) {
        offset = max
      }
      return offset
    },
    success: function() {
      this.isSuccess = true
      this.txt.innerHTML = '解锁成功'
      this.bgColor.style.backgroundColor = 'lightgreen'
      this.slider.className = 'slider active'
      // this.icon.className = 'iconfont icon-xuanzhong'
      //滑动成功时，移除鼠标按下事件和鼠标移动事件
      this.slider.onmousedown = null
      document.onmousemove = null
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../assets/css/allTime.css';
</style>