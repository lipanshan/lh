<template>
  <div class="footer">
    <div class="footer-box">
      <p>
        <span style="padding-left: 10px">企业服务</span>
        <span>使用与帮助</span>
        <span>联系我们</span>
        <img src="../assets/img/gjrc.png" alt />
      </p>
      <p>
        <span style="padding-left: 10px">用户搜索</span>
        <span>职业注册协议</span>
        <span>上海关键企业管理有限公司</span>
        <span class="right">企业服务热线和举报投诉 400 000 0000</span>
      </p>
      <p>
        <span style="padding-left: 10px">新闻资讯</span>
        <span>职业发布规则</span>
        <span style="width: auto;">公司地址：上海市静安区梅园路228号企业广场</span>
        <span style="float: right;">工作日 8:00 - 22:00</span>
      </p>
      <p>
        <span style="height: 30px;"></span>
        <span style="height: 29px"></span>
        <span>服务电话：021-62037982</span>
        <span style="float: right;">休息日 9:30 - 18:30</span>
      </p>
      <p>
        <span style="height: 30px;"></span>
        <span style="height: 29px"></span>
        <span>服务邮箱：kefu@guanjian.com</span>
      </p>
      <div class="beian">
        <div style="width: 210px;">Copyright © 2019</div>
        <div style="width: 170px;">京ICB备14013441号-5</div>
        <div>京ICP证150923号</div>
        <img src="../assets/img/inter.png" alt />
        <div>电子营业执照</div>
        <img src="../assets/img/police.png" alt />
        <div>京公网安备</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Footer'
}
</script>

<style lang="scss">
@import '../assets/css/index.css';
.footer {
  width: 100%;
  min-width: 1462px;
  .footer-box {
    margin: auto;
    width: 1462px;
    text-align: left;
  }
}
</style>